// export interface Product{

//     product_id:number;
//     uuid:string;
//     name :string;
//     description:string;
// 	price:number;
// 	imageUrl:string;
// }


export class Product{

    product_id:number=0;
    uuid:string="";
    name :string="";
    description:string="";
	price:number=0;
	imageUrl:string="";
}